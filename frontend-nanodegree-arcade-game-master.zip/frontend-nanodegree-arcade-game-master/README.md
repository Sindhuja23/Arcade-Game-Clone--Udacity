frontend-nanodegree-arcade-game
===============================

Getting Started
Step 1: Run the file index.html to load the game.
Step 2: Use keyboard arrows to move left, right, top and down.
Game Details
•	In this game you have a Player and Enemies (Bugs).
•	The goal of the player is to reach the water, without colliding into any one of the enemies.
•	The player can move left, right, up and down.
•	The enemies move in varying speeds on the paved block portion of the scene.
•	Once the player collides with an enemy, the game is reset and the player moves back to the start square.
•	Once the player reaches the water the game is won.


